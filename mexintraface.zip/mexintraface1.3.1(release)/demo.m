

%% demo detection
clear all; clc;
sdm=intraface.FaceAlignmentSDM('models\tracker_model49_131.bin');
im=imread('data\au12.png');
face = [180 106 272 272];
[pts,score] = sdm.detect(im,int32(face));
imshow(im); hold on;
intraface.plot2DFace(pts,'g-'); 
hold off;

%% demo tracking
clear all; clc;
vid = VideoReader('data/vid.wmv');
sdm = intraface.FaceAlignmentSDM('models\tracker_model49_131.bin');
fd  = intraface.FaceDetectorVJ('models\haarcascade_frontalface_alt2.xml');
curScore = 0;
lowScore = 0.1;
restart = true;
frameH = vid.Height;
minFaceSize = 0.1*[frameH frameH];
maxFaceSize = 0.8*[frameH frameH];

for i = 1:vid.NumberOfFrames
    im = read(vid,i);
    imshow(im); 
    if restart
        faces = fd.detect(im,'MinNeighbors',2,'MinSize',minFaceSize,'MaxSize',maxFaceSize);
        face  = intraface.largestFace(faces);
        if isempty(face)
            curScore = 0;
        else
            [pts,curScore] = sdm.detect(im,int32(face));
        end
    else
        [pts,curScore] = sdm.track(im,pts);
    end
    if curScore < lowScore
        restart = true;
    else
        restart = false;
        hold on; intraface.plot2DFace(pts,'g-'); hold off
    end
    drawnow;
end



