Copyright: Carnegie Mellon University


To run demo, the only you need to do is to add dll folder to your system path,
and restart Matlab. If you already installed OpenCV and has it on your system
path, please remove opencv from your system path.

If you want to call functions outside of this directory, add this folder to
the matlab path.

If you publish papers using this library, please cite following papers:

Xuehan Xiong and Fernando De la Torre. "Supervised Descent Method and its
Applications to Face Alignment". CVPR 2013.

and/or

Xuehan Xiong and Fernando De la Torre. "Supervised Descent Method for Solving Nonlinear Least Squares Problems in Computer Vision." arXiv preprint arXiv:1405.0601 (2014).

