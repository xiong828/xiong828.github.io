classdef FaceAlignmentSDM < handle
    %FACEALIGNMENTSDM Face Alignment using Supervised Descent Method
    %
    % The algorithm of:
    % > Xuehan Xiong and Fernando De la Torre. Supervised Descent Method 
    % > and its Applications to Face Alignment. CVPR, 2013.
    %
    % The basic usage is the following:
    %
    %    sdm = intraface.FaceAlignmentSDM('model_file');
    %    [lms,score] = sdm.detect(im,rect);
    %
    % See also intraface.FaceAlignmentSDM.FaceAlignmentSDM
    % intraface.FaceAlignmentSDM.detect
    % intraface.FaceAlignmentSDM.track
    %

    properties (SetAccess = private)
        % Object ID
        id
    end

    methods
        function this = FaceAlignmentSDM(varargin)
            %FACEALIGNMENTSDM  Create or load a new FaceAlignmentSDM object
            %
            %    sdm = intraface.FaceAlignmentSDM(filename)
            %    sdm = intraface.FaceAlignmentSDM(filename,'Offset',offset)
            %
            % ## Input
            % * __filename__ Filename of SDM model to load from
            %
            % ## Output
            % * __sdm_ SDM object
            %
            % ## Options
            % * __Offset__ Face Detector offset. 
            %
            % See also intraface.FaceAlignmentSDM
            %
            this.id = FaceAlignmentSDM_(0, 'new', varargin{:});
        end
        
        function [lms, score] = detect(this, im, rect)
            %DETECT  Performs facial feature detection given a face rectangle
            %
            %    [lms, score] = sdm.detect(im, rect)
            %
            % The detected landmarks are returned as a 2xn matrix.
            %
            % ## Input
            % * __im__ Matrix of the type uint8 containing an image where
            %       face alignment is performed.
            % * __rect__ Matrix of the type int32 containg an face rectangle
            %       (of the form `[x,y,width,height]`) where face 
            %       alignment is performed.
            %
            % ## Output
            % * __lms__ Matrix of the type single containing predicted
            %       facial landmarks.
            % * __score__ Prediction confidence score.
            %
            %
            % See also intraface.FaceAlignmentSDM
            %
            [lms, score] = FaceAlignmentSDM_(this.id, 'detect', im, rect);
            lms = lms + 1;
        end
        
        function [lms, score] = track(this, im, lms)
            %TRACK  Performs facial feature tracking given a previous
            %       prediction
            %
            %    [lms, score] = sdm.track(im, lms)
            %
            % The detected landmarks are returned as a 2xn matrix.
            %
            % ## Input
            % * __im__ Matrix of the type uint8 containing an image where
            %       face alignment is performed.
            % * __lms__ 2xn Matrix of the type single containing the previously
            %       predicted facial landmarks.
            %
            % ## Output
            % * __lms__ Matrix of the type single containing predicted
            %       facial landmarks.
            % * __score__ Prediction confidence score. A value between 0
            %       and 1, the higher the value the more confident about
            %       your prediction.
            %
            % See also intraface.FaceAlignmentSDM
            %
            lms = lms - 1;
            [lms, score] = FaceAlignmentSDM_(this.id, 'track', im, lms);
            lms = lms + 1;
        end

        function delete(this)
            %DELETE  Destructor
            %
            % See also intraface.FaceAlignmentSDM
            %
            FaceAlignmentSDM_(this.id, 'delete');
        end

        
    end

end
