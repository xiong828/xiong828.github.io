function hf = plot2DFace(x,varargin)
  if size(x,2) == 49
    idx = {1:5,6:10,11:14,15:19,[20:25 20],[26:31 26],[32:43 32],[44:49 44]};
  elseif size(x,2) == 66
    idx = {1:17, (1:5)+17,(6:10)+17,(11:14)+17,(15:19)+17,[20:25 20]+17,[26:31 26]+17,...
      [32:43 32]+17,[44:49 44]+17};
  else
    disp('plot2DFace::wrong number of landmarks');
    return;
  end
  
  for i = 1:length(idx),
    hf(i) = plot(x(1,idx{i}),x(2,idx{i}),varargin{:});
  end
end

