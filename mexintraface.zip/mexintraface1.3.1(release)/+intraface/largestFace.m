function face = largestFace(faces)
    if isempty(faces)
        face = [];
        return;
    end
    temp = reshape(cell2mat(faces),4,length(faces));
    [~,idx] = max(temp(3,:));
    face = faces{idx};
end